/*                      Corbit.Java  
	    

	          Applet to solve Kepler's equation
                   for circular orbit velocity.
			        Version 3.4a

		              Written by 
                          Tom Benson
                          TeJaun RiChard
                          Ian Breyfogle

>                              NOTICE
>This software is in the Public Domain.  It may be freely copied and used in
>non-commercial products, assuming proper credit to the author is given.  IT
>MAY NOT BE RESOLD.  If you want to use the software for commercial
>products, contact the author.
>No copyright is claimed in the United States under Title 17, U. S. Code.
>This software is provided "as is" without any warranty of any kind, either
>express, implied, or statutory, including, but not limited to, any warranty
>that the software will conform to specifications, any implied warranties of
>merchantability, fitness for a particular purpose, and freedom from
>infringement, and any warranty that the documentation will conform to the
>program, or any warranty that the software will be error free.
>In no event shall NASA be liable for any damages, including, but not
>limited to direct, indirect, special or consequential damages, arising out
>of, resulting from, or in any way connected with this software, whether or
>not based on warranty, contract, tort or otherwise, whether or not injury
>was sustained by persons or property or otherwise, and whether or not loss
>was sustained from, or arose out of the results of, or use of, the software
>or services provided hereunder.


What we were doing was basically adding graphics to the COrbit file, 
    so that they appear on the grid choice thingy. 
     Makes it look cooler while also adding a bit of a visual aid to it. 
      As of Friday, July 13, 2012. 
                          -TJ

For this portion of the software, we're adding subunits for time 
      (minutes, hours, seconds, etc.). 
      As of July 19, 2012
                          -TJ

      Add pictures of the planets ..
      Add "specify" to planet list
         Add sliders to radius and gravity

                            TJB - 2 Aug 12
*/

import java.awt.*;
import java.lang.Math ;

public class Corbit extends java.applet.Applet {

   double grav, gravd, planrad,alt, vel, altmax ;
   int lunits,lplanet, planetsave;
   int mode ;
   double Pi, time;
   double orbrad ;
   int sldloc;
   double scale;
   int tmode;
   double timeout, v1min, v1max, v2min, v2max, v3min, v3max, minorb, maxorb; 
   double gmin, gmax, pmin, pmax;
   double lenconv, tconv, xconv;

   In in ;
   Viewer view ;
   Image offscreenImg ;
   Graphics offsGg ;

   public void init() {

     setLayout(new GridLayout(1,2,0,0)) ;

     offscreenImg = createImage(this.size().width,
                      this.size().height) ;
     offsGg = offscreenImg.getGraphics() ;

     setDefaults () ;

     view = new Viewer(this) ;

     in = new In(this) ;

     add(in) ;
     add(view) ;

     computeCorbit() ;
     view.start();
  }
 
  public void setDefaults() {                      //THIS IS THE SET DEFAULTS
  
     lunits = 0;
     lplanet = 2;
     planetsave= lplanet;
     mode = 0 ;
     Pi= 3.1415926;
     sldloc= 80;
     lenconv= 1.0;
     xconv= 1.0;

     alt = 100. ;
     planrad = 3963.;
     orbrad=planrad+alt;
     grav = 32.2 ;
     gravd = grav * 2454.5455;
     vel = 17478. ;
     tmode= 0;
     time= 87.632;
     timeout= time;
     tconv= 1;
     altmax= 10000;

     getMinmax();
                                 //THIS IS WHERE WE SET THE MIN AND MAX...  
  }

  public void getMinmax() {
     v1min= 50;
     v1max= altmax;  //Miles
     gmin= 1.0;
     gmax= 100.0;
     pmin= 50.0;
     pmax= 100000.0;
     minorb = planrad + v1min;
     maxorb = planrad + v1max;
 
     v2max = Math.sqrt(gravd * planrad * planrad/minorb) ;  // mph
     v2min = Math.sqrt(gravd * planrad * planrad/maxorb);  // mph    

     v3min= Math.sqrt(4.0 * Pi * Pi *minorb* minorb *minorb/(gravd *planrad *planrad))*60.;  //Minutes
     v3max= Math.sqrt(4.0 * Pi * Pi *maxorb* maxorb *maxorb/(gravd *planrad *planrad))*60.;
  }


  public void computeCorbit() {
     String outht,outspd,tout  ;
     outht = "Miles" ;
     if (lunits == 1) outht = "Km" ;
     outspd = "MPH"  ;
     if (lunits == 1) outspd = "Km/H"  ;
     tout= "Min.";
        if (tmode == 1){
            tout= "Days";
        }
        if (tmode ==2){
            tout= "Hours";
         }

      orbrad=planrad+alt;

     if (mode == 0) {  // altitude input 
        vel = Math.sqrt(gravd * planrad * planrad / (orbrad)) ;  // mph
        time= Math.sqrt(4.0 * Pi * Pi *orbrad* orbrad *orbrad/(gravd *planrad *planrad))*60.; //Minutes
     }
     if (mode == 1) {  // velocity input
        alt = ((gravd * planrad * planrad / (vel * vel)) - planrad) ;  // miles
        orbrad=planrad+alt;
        time= Math.sqrt(4.0 * Pi * Pi * Math.pow(orbrad, 3)/(gravd *planrad *planrad))*60.; //Minutes
     }
     if (mode == 2) { //time input
        orbrad= Math.pow(((time * time * gravd * planrad * planrad )/ (4 * Pi * Pi * 60 * 60)), 1.0/3.0);
        orbrad= Math.abs(orbrad);
        alt= orbrad-planrad; //Miles
        vel = Math.sqrt(gravd * planrad * planrad / (orbrad)) ;  // mph 
     }
     timeout=time/tconv;
        
       in.dn.left.o5.setText(String.valueOf(filter0(alt*lenconv))) ;
       in.dn.left.o6.setText(String.valueOf(filter0(vel*lenconv))) ;
       in.dn.left.o7.setText(String.valueOf(filter3(timeout))) ;
       in.dn.left.lu5.setText(outht) ;
       in.dn.left.lu6.setText(outspd) ;
       in.dn.left.lu7.setText(tout) ;

	view.repaint();
  }
 
  public int filter0(double inumbr) {
     //  integer output
       float number ;
       int intermed ;

       intermed = (int) (inumbr) ;
       number = (float) (intermed);
       return intermed ;
  }
 
  public float filter3(double inumbr) {
     //  output only to .001
       float number ;
       int intermed ;
  
       intermed = (int) (inumbr * 1000.) ;
       number = (float) (intermed / 1000. );
       return number ;
  }

  public float filter5(double inumbr) {
     //  output only to .00001
       float number ;
       int intermed ;
  
       intermed = (int) (inumbr * 100000.) ;
       number = (float) (intermed / 100000. );
       return number ;
  }

  class In extends Panel {
     Corbit outerparent ;
     Titl titl ;
     Up up ;
     Dn dn ;

     In (Corbit target) {                           
        outerparent = target ;
        setLayout(new GridLayout(3,1,5,5)) ;

        titl = new Titl(outerparent) ;
        up = new Up(outerparent) ;
        dn = new Dn(outerparent) ;

        add(titl) ;
        add(up) ;
        add(dn) ;
     } 
                                       //TOP HEADLINE, EXPLAINS APPLET
     class Titl extends Panel {
        Label la,lb,lc,ld,le ;
        Label lc1,lc2,la1,la2,ld1,ld2,ld3,ld4 ;
        Label lab;
        Label lb2,lb3,lb4,lb5;
        Choice untch,Tchoice;

        Titl (Corbit target) {                           
            outerparent = target ;
            setLayout(new GridLayout(5,5,0,0)) ;

            lc = new Label("Circular ", Label.RIGHT) ;
            lc1 = new Label("Orbit ", Label.CENTER) ;
            lc2 = new Label("Calculator", Label.LEFT) ;

            la = new Label("Choose your", Label.RIGHT) ;
            la.setForeground(Color.black) ;
            la1 = new Label(" units and get ", Label.CENTER) ;
            la1.setForeground(Color.black) ;
            la2 = new Label(" started!", Label.LEFT) ;
            la2.setForeground(Color.black) ;

            lb = new Label("Version 3.4a", Label.CENTER) ;
            lb.setForeground(Color.white) ;
	       lb.setBackground(Color.blue) ;
		
		lb2 = new Label(" ", Label.CENTER) ;
            lb2.setForeground(Color.white) ;
	       lb2.setBackground(Color.blue) ;

		lb3 = new Label(" ", Label.CENTER) ;
            lb3.setForeground(Color.white) ;
	       lb3.setBackground(Color.blue) ;

		lb4 = new Label(" ", Label.CENTER) ;
            lb4.setForeground(Color.white) ;
	       lb4.setBackground(Color.blue) ;

		lb5 = new Label(" ", Label.CENTER) ;
            lb5.setForeground(Color.white) ;
	       lb5.setBackground(Color.blue) ;

            ld = new Label("Written by: ", Label.CENTER) ;
            ld.setForeground(Color.white) ;
	       ld.setBackground(Color.blue) ;

            ld1 = new Label("Tom Benson,", Label.CENTER) ;
            ld1.setForeground(Color.white) ;
	       ld1.setBackground(Color.blue) ;

            ld2 = new Label("TeJaun RiChard,", Label.LEFT) ;
            ld2.setForeground(Color.white) ;
	       ld2.setBackground(Color.blue) ;

            ld3 = new Label("& Ian Breyfogle ", Label.LEFT) ;
            ld3.setForeground(Color.white) ;
	       ld3.setBackground(Color.blue) ;
            
            ld4 = new Label(" ", Label.LEFT) ;
            ld4.setForeground(Color.white) ;
	       ld4.setBackground(Color.blue) ;

            lab = new Label("Input Choice", Label.RIGHT) ;
            lab.setForeground(Color.blue) ;

            Tchoice = new Choice();
            Tchoice.addItem("Minutes");
            Tchoice.addItem("Days");
            Tchoice.addItem("Hours");
            Tchoice.select(0);

            untch = new Choice() ;
            untch.addItem("English") ;
            untch.addItem("Metric");
            untch.select(0) ;
                                                                 
            add(new Label (" ", Label.CENTER)) ;
            add(lc) ;
            add(lc1) ;
            add(lc2) ;
            add(new Label (" ", Label.CENTER)) ;

            add(ld) ;
            add(ld1) ;
            add(ld2) ;
            add(ld3) ;
            add(ld4) ;

            add(lb2) ;
            add(lb3) ;
            add(lb) ;
            add(lb4) ;
            add(lb5) ;  

            add(new Label (" ", Label.CENTER)) ;
            add(la) ;
            add(la1) ;
            add(la2) ;
            add(new Label (" ", Label.CENTER)) ;

            add(new Label(" ", Label.RIGHT)) ;
            add(new Label("Units: ", Label.RIGHT)) ;
            add(untch) ;
            add(new Label("Time: ", Label.RIGHT)) ;
            add(Tchoice);      
        }

        public boolean action(Event evt, Object arg) {
            if(evt.target instanceof Choice) {
               this.handleProb(arg) ;
               return true ;
            }

            else return false ;
        }
 
        public void handleProb(Object obj) {
           String outht,outg  ;

           lunits  = untch.getSelectedIndex() ;
           tmode   = Tchoice.getSelectedIndex();

           outht = " miles " ;
           if (lunits == 1) outht = " km " ;
           outg = " ft/sec^2 "  ;
           if (lunits == 1) outg = " m/sec^2 "  ;
     
           if (lunits == 0) {
               lenconv= 1;
               xconv= 1;
               
               in.up.left.o3.setText(String.valueOf(filter3(grav))) ;
               in.up.left.o4.setText(String.valueOf(filter0(planrad))) ;
               in.up.left.lu3.setText("ft/s^2") ;
               in.up.left.lu4.setText("Miles") ;
           }
           if (lunits == 1) {
               lenconv= 1.609;
               xconv= .3048;
               in.up.left.o3.setText(String.valueOf(filter3(grav  * xconv))) ;
               in.up.left.o4.setText(String.valueOf(filter0(planrad * lenconv))) ;
               in.up.left.lu3.setText("m/s^2") ;
               in.up.left.lu4.setText("KM") ;
           }
           if (tmode == 0) {
               tconv= 1;
           }
  
           if (tmode == 1) {
               tconv= 60*24;
           }

           if (tmode ==2) {
               tconv= 60;
           }
           computeCorbit() ;
        }
     }
                                 //THIS IS THE BEGINNING OF "UP"
     class Up extends Panel {
        Corbit outerparent ;
        Left left;
        Right right;

       Up (Corbit target) {                           
        outerparent = target ;
        setLayout(new GridLayout(1,2,5,5)) ;

        left= new Left(outerparent);
        right= new Right(outerparent);

        add(left) ;
        add(right) ;
      } 
                                   //THIS IS THE BEGINNING OF "LEFT"
        class Left extends Panel {
          TextField o3,o4,o25 ;
          Label lu3,lu4,lu8;
          Choice plntch ;

          Left (Corbit target) {                           
            outerparent = target ;
            setLayout(new GridLayout(5,3,0,0)) ;           

            lu3 = new Label("ft/s^2", Label.CENTER) ;
            o3 = new TextField("32.2 ",5) ;
            o3.setBackground(Color.black) ;
            o3.setForeground(Color.yellow) ;
           
            lu4 = new Label("Miles", Label.CENTER) ;
            o4 = new TextField("3963",5) ;
            o4.setBackground(Color.black) ;
            o4.setForeground(Color.yellow) ;

            lu8 = new Label ("Miles", Label.CENTER);
            o25 = new TextField("10000", 5);
            o25.setBackground(Color.white) ;
            o25.setForeground(Color.black) ;
 
            plntch = new Choice() ;
            plntch.addItem("Mercury");
            plntch.addItem("Venus");
            plntch.addItem("Earth") ;
            plntch.addItem("Moon");
            plntch.addItem("Mars");
            plntch.addItem("Jupiter");
            plntch.addItem("Saturn");
            plntch.addItem("Uranus");
            plntch.addItem("Neptune");
		plntch.addItem("Specify");
            plntch.select(2) ;

            add(new Label (" Planet:", Label.CENTER)) ;
            add(plntch) ;
            add(new Label (" ", Label.CENTER)) ;

            add(new Label("Gravity", Label.CENTER))  ;
            add(o3) ;
            add(lu3) ;
 
            add(new Label("Radius", Label.CENTER)) ;
            add(o4) ;
            add(lu4) ;

            add(new Label ("Max Alt ", Label.CENTER)) ;
            add(o25) ;
            add(lu8) ;

            add(new Label (" ", Label.CENTER)) ;
            add(new Label (" ", Label.CENTER)) ;
            add(new Label (" ", Label.CENTER)) ;
        }

        public boolean action(Event evt, Object arg) {
            if(evt.target instanceof Choice) {
               this.handleCho(arg) ;
               return true ;
            }

            if(evt.target instanceof TextField) {
               this.handleText(evt,arg) ;
               return true ;
            }
 
            else return false ;
        }
 
        public void handleCho(Object obj) {
           lplanet = plntch.getSelectedIndex() ;

           if (lplanet == 0) {           // Mercury
               grav = .378*32.2;
               planrad = 1516. ;
           }
           
           if (lplanet == 1) {           //Venus
               grav = .906*32.2;
               planrad = 3760.;
           }
 
           if (lplanet == 2) {           // Earth
               grav = 32.2  ;
               planrad = 3963. ;
           }
           if (lplanet == 3) {           // Moon
               grav = 5.3  ;
               planrad = 1079.5 ;
           }
           if (lplanet == 4) {           // Mars
               grav = 12.1  ;
               planrad = 2111. ;
           }
           if (lplanet == 5) {            //Jupiter
               grav = 81.43  ;
               planrad = 44424 ;
           }
           if (lplanet == 6) {            //Saturn
               grav =  34.32 ;
               planrad = 37449 ;
           }

           if (lplanet == 7)  {           //Uranus
	       grav = 29.07  ;
               planrad = 15882. ;                                        
           }
           if (lplanet == 8)  {           //Neptune
	       grav = 35.29 ;
               planrad = 15389 ;   
           }
           if (lplanet == 9)  {          //Specify
             grav = 32.2 ;
               planrad = 3963. ;                                     
           }
           gravd = grav * 2454.5455;
           if (lplanet == 9)  {
             o3.setBackground(Color.white) ;
             o3.setForeground(Color.black) ;
             o4.setBackground(Color.white) ;
             o4.setForeground(Color.black) ;
           }
           else {
             o3.setBackground(Color.black) ;
             o3.setForeground(Color.yellow) ;
             o4.setBackground(Color.black) ;
             o4.setForeground(Color.yellow) ;
           }
           alt= 100;
           orbrad=planrad+alt;      
           mode= 0;
           in.dn.left.Altitude.setBackground (Color.yellow);
           in.dn.left.Velocity.setBackground (Color.white);
           in.dn.left.Time.setBackground (Color.white); 
           in.dn.left.o5.setBackground(Color.white);
           in.dn.left.o5.setForeground(Color.black);
           in.dn.left.o6.setBackground(Color.black);
           in.dn.left.o6.setForeground(Color.yellow);
           in.dn.left.o7.setBackground(Color.black);
           in.dn.left.o7.setForeground(Color.yellow);
           getMinmax(); 

           if (lunits == 0) {             
               in.up.left.o3.setText(String.valueOf(filter3(grav))) ;
               in.up.left.o4.setText(String.valueOf(filter0(planrad))) ;
               in.up.left.lu3.setText("ft/s^2") ;
               in.up.left.lu4.setText("Miles") ;
           }
           if (lunits == 1) {
               in.up.left.o3.setText(String.valueOf(filter3(grav  * .3048))) ;
               in.up.left.o4.setText(String.valueOf(filter0(planrad * 1.609))) ;
               in.up.left.lu3.setText("m/s^2") ;
               in.up.left.lu4.setText("KM") ;
           }     
           computeCorbit() ;
        } // end of handler for choice buttons

        public void handleText(Event evt, Object obj) {
           Double V1, V2, V3, V4 ;
           double v1, v2, v3, v4;
                                           //THIS IS TJ SETTING MAX ALT. 
           V2 = Double.valueOf(o25.getText());
           v2 = V2.doubleValue();
           altmax=v2/lenconv;
           
           if (lplanet == 9){

              V3 = Double.valueOf(o3.getText());
              v3 = V3.doubleValue();
              grav=v3/xconv;
              gravd = grav * 2454.5455;
           
              V4 = Double.valueOf(o4.getText());
              v4 = V4.doubleValue();
              planrad=v4/lenconv;
          }
           getMinmax();

           computeCorbit() ;
         }    // end of handler for text
       }          //THIS IS THE END OF "Left"

                  // Beginning of Right
       class Right extends Panel {
           Corbit outerparent ;
           Scrollbar s3, s4;

           Right (Corbit target) {
            int i2,i3,i4 ;
            outerparent = target ;
            setLayout(new GridLayout(5,1,5,5)) ;
            
            i3 = (int) (((grav - gmin)/(gmax - gmin))*1000.) ;
            i4 = (int) (((planrad - pmin)/(pmax - pmin))*1000.) ;
 
            s3 = new Scrollbar(Scrollbar.HORIZONTAL,i3,10,0,1000);
            s4 = new Scrollbar(Scrollbar.HORIZONTAL,i4,10,0,1000);

            add(new Label("To enable sliders, select Specify", Label.CENTER)) ;
            add(s3) ;
            add(s4) ;
            add(new Label(" ", Label.CENTER)) ;
            add(new Label(" ", Label.CENTER)) ;
          }

          public boolean handleEvent(Event evt) {

            if(evt.id == Event.SCROLL_ABSOLUTE) {
               this.handleBar(evt) ;
               return true ;
            }
            if(evt.id == Event.SCROLL_LINE_DOWN) {
               this.handleBar(evt) ;
               return true ;
            }
            if(evt.id == Event.SCROLL_LINE_UP) {
               this.handleBar(evt) ;
               return true ;
            }
            if(evt.id == Event.SCROLL_PAGE_DOWN) {
               this.handleBar(evt) ;
               return true ;
            }
            if(evt.id == Event.SCROLL_PAGE_UP) {
               this.handleBar(evt) ;
               return true ;
            }
            else return false ;
          }

          public void handleBar(Event evt) {
             int i3, i4;
             double v3, v4;
             float fl3, fl4;

          if (lplanet == 9) {  // gravity/radius planet input
                   i3 = s3.getValue() ;
                   v3 = i3 * (gmax - gmin)/ 1000. + gmin ;
                   fl3 = (float) v3 ;
                   left.o3.setText(String.valueOf(fl3)) ;
                   grav= v3/ xconv ;
                   gravd = grav * 2454.5455;
                 
                   i4 = s4.getValue() ;
                   v4 = i4 * (pmax - pmin)/ 1000. + pmin ;
                   fl4 = (float) v4 ;
                   left.o4.setText(String.valueOf(fl4)) ;
                   planrad= v4/ lenconv ;
              
             }

          getMinmax();

           computeCorbit() ;
          }  // end of handler
       }         //THIS SHOULD BE THE END OF "RIGHT"
     }           //THIS IS THE END OF "UP"

                 //THIS IS THE BEGINNING OF "DOWN"
     class Dn extends Panel {
        Corbit outerparent ;
        Left left;
        Right right;

       Dn (Corbit target) {                           
        outerparent = target ;
        setLayout(new GridLayout(1,2,5,5)) ;

        left= new Left(outerparent);
        right= new Right(outerparent);

        add(left) ;
        add(right) ;
      } 
                                      //THIS IS THE BEGINNING OF "LEFT"
        class Left extends Panel {
           Corbit outerparent ;
           TextField o1,o5,o6, o7 ;
           Label l1u,l5,l6, l7 ;
           Label lu5,lu6, lu7;
           Button compb ;
           Button Altitude, Velocity, Time;
           
           Left (Corbit target) {
            outerparent = target ;
            setLayout(new GridLayout(5,3,5,5)) ;
 
            compb = new Button("Compute") ;
            compb.setBackground(Color.yellow) ;
            compb.setForeground(Color.black) ;

            Altitude= new Button ("Altitude");
            Altitude.setForeground (Color.black);
            Altitude.setBackground (Color.yellow);

            Velocity= new Button ("Velocity");
            Velocity.setForeground (Color.black);
            Velocity.setBackground (Color.white);

            Time= new Button ("Time");
            Time.setForeground (Color.black);
            Time.setBackground (Color.white);
 
            lu5 = new Label("Miles", Label.CENTER) ;
            o5 = new TextField("100",5) ;
            o5.setBackground(Color.white) ;
            o5.setForeground(Color.black) ;

            lu6 = new Label("MPH", Label.CENTER) ;
            o6 = new TextField("17478",5) ;
            o6.setBackground(Color.black) ;
            o6.setForeground(Color.yellow) ;
     
            lu7 = new Label("Minutes", Label.CENTER) ;
            o7 = new TextField("90", 5);
            o7.setBackground(Color.black) ;
            o7.setForeground(Color.yellow) ;
 
            add(new Label("Input", Label.RIGHT)) ;            
            add(new Label(" Choice", Label.LEFT)) ;            
            add(new Label(" ", Label.RIGHT)) ;            
           
            add(Altitude) ;
            add(o5) ;
            add(lu5) ;
            
            add(Velocity) ;
            add(o6) ;
            add(lu6) ;
            
            add(Time);
            add(o7);
            add(lu7);

            add(new Label("Press -->", Label.RIGHT)) ;
            add(compb) ;
            add(new Label(" ", Label.RIGHT)) ;            
        }
                                     //INSTANCE OF BUTTON BEING PRESSED
        public boolean action(Event evt, Object arg) {

            if(evt.target instanceof Button) {
               this.handleText(evt,arg) ;
               return true ;
            }
 
            else return false ;
        }

        public void handleText(Event evt, Object obj) {
           Double V1, V2, V3, V4 ;
           double v1, v2, v3, vmax, vmin, minorb, v4;
           String label;
           label= (String)obj;

           if (label.equals("Altitude")) {
                Altitude.setBackground (Color.yellow);
                Velocity.setBackground (Color.white);
                Time.setBackground (Color.white); 
                in.dn.left.o5.setBackground(Color.white);
                in.dn.left.o5.setForeground(Color.black);
                in.dn.left.o6.setBackground(Color.black);
                in.dn.left.o6.setForeground(Color.yellow);
                in.dn.left.o7.setBackground(Color.black);
                in.dn.left.o7.setForeground(Color.yellow);
              
                mode= 0;
           }   
            if (label.equals("Velocity")) {
                Altitude.setBackground (Color.white);
                Velocity.setBackground (Color.yellow);
                Time.setBackground (Color.white);
                in.dn.left.o5.setBackground(Color.black);
                in.dn.left.o5.setForeground(Color.yellow);
                in.dn.left.o6.setBackground(Color.white);
                in.dn.left.o6.setForeground(Color.black);
                in.dn.left.o7.setBackground(Color.black);
                in.dn.left.o7.setForeground(Color.yellow);
                mode = 1;
           } 
            if (label.equals("Time")) {
                Altitude.setBackground (Color.white);
                Velocity.setBackground (Color.white);
                Time.setBackground (Color.yellow);
                in.dn.left.o5.setBackground(Color.black);
                in.dn.left.o5.setForeground(Color.yellow);
                in.dn.left.o6.setBackground(Color.black);
                in.dn.left.o6.setForeground(Color.yellow);
                in.dn.left.o7.setBackground(Color.white);
                in.dn.left.o7.setForeground(Color.black);
                mode= 2;
           } 

           if (label.equals("Compute")) {
                                           //THIS IS TJ SETTING MAX ALT. 
               V4 = Double.valueOf(in.up.left.o25.getText());
               v4 = V4.doubleValue();
               altmax=v4/lenconv;
               getMinmax();

               if (mode == 0) {  // altitude input
                   V1 = Double.valueOf(o5.getText()) ;
                   v1 = V1.doubleValue() ;

                   if (v1 < v1min* lenconv) {
                      v1 = v1min* lenconv ;
                      o5.setText(String.valueOf(filter0(v1))) ;
                   }
                   if (v1 >v1max*lenconv) {
                      v1 = v1max*lenconv ;
                      o5.setText(String.valueOf(filter0(v1))) ;
                   }
                
                   alt = v1/lenconv ;
              
               }

               if (mode == 1) { // velocity input 
                  V2 = Double.valueOf(o6.getText()) ;
                  v2 = V2.doubleValue() ;
                   if (v2 < v2min*lenconv) {
                      v2 = v2min*lenconv ;
                      o6.setText(String.valueOf(filter0(v2))) ;
                   }
                   if (v2 > v2max*lenconv) {
                      v2 = v2max*lenconv ;
                      o6.setText(String.valueOf(filter0(v2))) ;
                   }
                   
                     vel= v2 / lenconv;
               }
               if (mode ==2) {// time input
                  V3 = Double.valueOf(o7.getText()) ;
                  v3 = V3.doubleValue() ;
                  if (v3 < v3min/tconv) {
                      v3 = v3min ;
                      o7.setText(String.valueOf(filter3(v3))) ;
                   }
                  if (v3 > v3max/tconv) {
                      v3 = v3max ;
                      o7.setText(String.valueOf(filter3(v3))) ;
                  }
                  timeout= v3;
                  time= timeout* tconv;
              }     

               computeCorbit() ;
            }
         }    // end of handler
    }         //THIS IS THE END OF "LEFT"


       class Right extends Panel {
           Corbit outerparent ;
           Scrollbar s1, s2, s3 ;
           Label l1;

           Right (Corbit target) {
            int i1,i2,i3 ;
            outerparent = target ;
            setLayout(new GridLayout(5,1,5,5)) ;

            i1 = (int) (((alt - v1min)/(v1max - v1min))*1000.) ;
            i2 = (int) (((vel - v2min)/(v2max - v2min))*1000.) ;
            i3 = (int) (((time - v3min)/(v3max-v3min))*1000.) ;
 
            s1 = new Scrollbar(Scrollbar.HORIZONTAL,i1,10,0,1000);
            s2 = new Scrollbar(Scrollbar.HORIZONTAL,i2,10,0,1000);
            s3 = new Scrollbar(Scrollbar.HORIZONTAL,i3,10,0,1000);

            add(new Label(" Interactive Sliders ", Label.CENTER)) ;
            add(s1) ;
            add(s2) ;
            add(s3) ;
            add(new Label(" ", Label.CENTER)) ;
          }

          public boolean handleEvent(Event evt) {

            if(evt.id == Event.SCROLL_ABSOLUTE) {
               this.handleBar(evt) ;
               return true ;
            }
            if(evt.id == Event.SCROLL_LINE_DOWN) {
               this.handleBar(evt) ;
               return true ;
            }
            if(evt.id == Event.SCROLL_LINE_UP) {
               this.handleBar(evt) ;
               return true ;
            }
            if(evt.id == Event.SCROLL_PAGE_DOWN) {
               this.handleBar(evt) ;
               return true ;
            }
            if(evt.id == Event.SCROLL_PAGE_UP) {
               this.handleBar(evt) ;
               return true ;
            }
            else return false ;
          }


          public void handleBar(Event evt) {
             int i1, i2, i3;
             double v1, v2, v3;
             float fl1, fl2, fl3;

          if (mode == 0) {  // altitude input
                   i1 = s1.getValue() ;
                   v1 = i1 * (v1max - v1min)/ 1000. + v1min ;
                   fl1 = (float) v1 ;
                   left.o5.setText(String.valueOf(fl1)) ;
                   alt= v1;
             }

          if (mode ==1) { //Velocity input
                   i2 = s2.getValue() ;
                   v2 = i2 * (v2max - v2min)/ 1000. + v2min ;
                   fl2 = (float) v2 ;
                   left.o6.setText(String.valueOf(fl2)) ;
                   vel= v2;
             }
          if (mode ==2) { // Time Input
                i3 = s3.getValue() ;
                v3 = i3 * (v3max - v3min)/ 1000. + v3min ;
                fl3 = (float) v3 ;
                left.o7.setText(String.valueOf(fl3)) ;
                time= v3;
             } 
                   computeCorbit() ;
          }
       }                                  //THIS SHOULD BE THE END OF "RIGHT"
     }                                   //THIS SHOULD BE THE END OF "DOWN" 
  }                                      //THIS IS THE END OF "IN"
 
  class Viewer extends Canvas
         implements Runnable{
     Corbit outerparent ;
     Thread runner ;
     Point locate, anchor;
     Image plntimg ;
     	
	int xloc, yloc, xctr, yctr, pixrad, pixorbrad;
        double theta;

     Viewer (Corbit target) {
         setBackground(Color.black) ;
         runner = null ;
     }

     public Insets insets() {
        return new Insets(0,10,0,10) ;
     }
 
     public void start() {
        if (runner == null) {
           runner = new Thread(this) ;
           runner.start() ;
        }
     xloc= 82;
     yloc= 82;
     xctr= 200;
     yctr= 200; 
     pixrad= 50;
     pixorbrad= 60;
     theta= 0.0;

     }

          //Mouse slider thingy. Allows for the movement of the planet 
          //   around the black screen                                      
          //   (space, in essence).     
     public boolean mouseUp(Event evt, int x, int y) {
        handleb(x,y) ;
        return true;
     }

     public boolean mouseDrag(Event evt, int x, int y) {
        handle(x,y) ;
        return true;
     }
     public boolean mouseDown(Event evt, int x, int y) {
        anchor= new Point(x,y) ;
        return true;
     }

     
     public void handle(int x, int y) { 
        locate= new Point(x,y); 
        if(locate.x <300) {
        	xctr=xctr+(locate.x-anchor.x)/4;
        	yctr=yctr+(locate.y-anchor.y)/4;
       }       
        if(locate.x >320 && (locate.y > 10 && locate.y<350)) {
                sldloc=locate.y; 
        }
        view.repaint() ;
     } 
     
      public void handleb(int x, int y) { 
        if(x>350 && y>370) {
           xctr= 200;
           yctr= 200;
        }       
     } 
     public void run() {
     double dtheta;
       int timer ;
 
       timer = 100 ;
       while (true) {
          try { Thread.sleep(timer); }
          catch (InterruptedException e) {} 
          dtheta= 10.0* 90.0*Pi/(180.0*time);
          theta= theta+dtheta;
          view.repaint() ;
//in.dn.o25.setText(String.valueOf(filter5(scale))) ;
        }
     }

     public void update(Graphics g) {
         view.paint(g) ;
     }

     public void paint(Graphics g) {
     String a;
       int i,k ;
       int exes[] = new int[10] ;
       int whys[] = new int[10] ;
       int xcir, ycir, xorb, yorb;
       int iwidth,iheight,xpic,ypic ;
       double rsld; 
       
        iwidth =100 ;

//      offsGg.setColor(Color.white) ;
       offsGg.setColor(Color.black) ;
       offsGg.fillRect(0,0, 400,500) ;
       //offsGg.setColor(Color.white) ;
       //offsGg.drawString("I wonder what this'll look like...", 10,10);
       rsld= sldloc;
 
       scale= (679.9-1.99*rsld)/330.0;

// Drawing the planet. Scales the size and sets a color depending on the choice 
//      the user makes (For instance, Earth= Blue)
     if (lplanet ==0) {
         plntimg = getImage(getCodeBase(),"mercury.jpg");  
         offsGg.setColor(Color.lightGray) ;
       }
     if (lplanet ==1) {
         plntimg = getImage(getCodeBase(),"venus.jpg");  
         offsGg.setColor(Color.gray) ;
       }
     if (lplanet ==2) {
         offsGg.setColor(Color.blue) ;
         plntimg = getImage(getCodeBase(),"earth.jpg");
       }
     if (lplanet ==3) {
         offsGg.setColor(Color.white) ; 
         plntimg = getImage(getCodeBase(),"moon.jpg");
       }
     if (lplanet ==4) {
         offsGg.setColor(Color.red) ; 
         plntimg = getImage(getCodeBase(),"mars.jpg");  
       }
     if (lplanet ==5) {
         offsGg.setColor(Color.orange) ; 
         plntimg = getImage(getCodeBase(),"jupiter.jpg"); 
       }
     if (lplanet ==6) {
         offsGg.setColor(Color.orange) ;  
         plntimg = getImage(getCodeBase(),"saturn.jpg"); 
       }
     if (lplanet ==7) {
         offsGg.setColor(Color.green) ;  
         plntimg = getImage(getCodeBase(),"uranus.jpg");  
       }
     if (lplanet ==8) {
         offsGg.setColor(Color.blue) ;
         plntimg = getImage(getCodeBase(),"neptune.jpg");  
       }
       pixrad=(int)(scale*planrad*1.0/80.0);
       xcir= xctr-pixrad;
       ycir= yctr-pixrad;
       offsGg.setColor(Color.blue);
       offsGg.fillOval(xcir, ycir, 2 * pixrad, 2 * pixrad) ;
      if (lplanet <=8) {
         iwidth = plntimg.getWidth(this) ;
         iheight = plntimg.getHeight(this) ;
         if(lplanet == 6) iheight = iheight + 200 ;
         iwidth = (int) (iwidth * scale*1.0/3.) ; 
         iheight = (int) (iheight * scale*1.0/3.) ; 
         xpic = xctr - iwidth/2 ;
         ypic = yctr - iheight/2 ;
         offsGg.drawImage(plntimg,xpic,ypic,iwidth,iheight,this) ;    
      } 
        
//This is the orbit. Space makes this easier to read as well. 
       pixorbrad=(int)(scale*orbrad*1.0/80.0);
       xorb=xctr-pixorbrad;
       yorb=yctr-pixorbrad;
       offsGg.setColor(Color.white);
       offsGg.drawOval(xorb, yorb, 2*pixorbrad,2* pixorbrad);
//Something goes here regarding orbit position. Space makes it easier to read .
       xloc=(int)(pixorbrad*Math.cos(theta)+xctr);
       yloc=(int)(-pixorbrad*Math.sin(theta)+yctr);
       offsGg.setColor(Color.yellow);
       offsGg.fillOval(xloc-5, yloc-5, 10,10);
       offsGg.setColor(Color.orange);
//offsGg.drawString("Tom says he doesn't care.", 10,20);  

       offsGg.setColor(Color.yellow);
       offsGg.fillRect(350,370,50,20);
       offsGg.setColor(Color.blue);
       offsGg.drawString("Find", 360,385);  
        
//This is the part where we put the slider in.
       offsGg.setColor(Color.white);
       offsGg.drawLine(380, 10, 380,350);
       offsGg.fillRect(360,sldloc,40,10); 
//That's just the closing
       g.drawImage(offscreenImg,0,0,this) ;
    }

  }
}
